export const PAYMENT_METHOD_NAME = 'yith-request-a-quote';

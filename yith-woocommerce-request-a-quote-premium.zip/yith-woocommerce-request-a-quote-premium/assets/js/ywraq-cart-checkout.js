jQuery(document).ready(function ($) {

	var cartQuotePopup = $('#ywraq-request-a-quote-on-cart');


});